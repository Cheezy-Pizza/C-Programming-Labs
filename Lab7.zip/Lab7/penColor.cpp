#include "penColor.h"

char* changePenColor(char *commandString){
    char penColor;
    system("CLS");
    //red, orange, yellow, green, blue, indigo and violet
    printf("Pick any color you'd like! ^-^ Colors Available:\n\
Red    - R,\n\
Orange - O,\n\
Yellow - Y,\n\
Green  - G,\n\
Blue   - B,\n\
Indigo - I,\n\
Violet - V,\n\
White  - W,\n\
Color choice: ");
    scanf(" %c",&penColor);
    getchar();
     switch (penColor){
        case 'R':
           sprintf(commandString,"PEN_COLOR %d %d %d\n", 255, 0, 0);
           break;
        case 'O':
           sprintf(commandString,"PEN_COLOR %d %d %d\n", 255, 127, 0);
           break;
        case 'Y':
            sprintf(commandString,"PEN_COLOR %d %d %d\n", 255, 255, 0);
           break;
        case 'G':
           sprintf(commandString,"PEN_COLOR %d %d %d\n", 0, 255, 0);
           break;
        case 'B':
            sprintf(commandString,"PEN_COLOR %d %d %d\n", 0, 0, 255);
           break;
        case 'I':
           sprintf(commandString,"PEN_COLOR %d %d %d\n", 75, 0, 130);
           break;
        case 'V':
           sprintf(commandString,"PEN_COLOR %d %d %d\n", 148, 0, 211);
           break;
        case 'W':
           sprintf(commandString,"PEN_COLOR %d %d %d\n", 255, 255, 255);
           break;
        default:
           break;
        }
        return commandString;
}