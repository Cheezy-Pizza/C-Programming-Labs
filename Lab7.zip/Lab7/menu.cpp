/*|Pointers & Arrays|--------------------------------------------------------//
#
# Project: Lab6
# Program: ROBT1270
#
# Description:
#   A collection of three functions that:
#   -Generates a selectable menu
#   -Generates a scrollable menu
#
# Author: Peter Stogneff
# Date Created: 02/26/2025
# Last Modified: 03/19/2025
# ---------------------------------------------------------------------------*/

/*|Defininitions and Includes|-----------------------------------------------*/
#include "Menu.h"

    // -------EXAMPLE OF HOW TO USE GENERATE MENU -------- //
    /*//initiailize the strings for the menu
    char titleText[80] = "Lab 6: Pointers and Arrays";
    const int optionNum[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
    const char *options[10] = {
    "------- EXIT -------",
    "Answers to ELEX 2220",
    "Answers to MATH 2342",
    "Answers to MECH 1210",
    "Really Bad Sort.....",
    "Sort Array Example..",
    "Classic Menu Style..",
    "Cursor Menu Style...",
    "Scrolling Menu Style",
    "Condensed Menu Style"};
    //color and clear system
    system("COLOR 0A");
    system("CLS");
    //generate starting menu
    int select = generateMenu( titleText, options, sizeof(optionNum)/sizeof(optionNum[0]));*/

/*|generateMenu|-------------------------------------------------------------//
#
# Description:
# This function... Generates a selectable menu
#
# Inputs:
# char* title - title of the menu as a string or char array
# const char* items - string values of each selection as an array pointer
# const int nItems - number of the menu items
#
# Returns: select - menu item selected
#
# Last Modified: March 5, 2025 by Peter Stogneff
# ---------------------------------------------------------------------------*/
int generateMenu(char*title, const char*items[], const int nItems){   
    system("CLS"); //clear the screen before printing
    printf("%s\n><*><*><*><*><*><*><*>*<*>< \n",title); //print title name and header
    for (int i = 0; i < nItems; i++) //print out all the items
    {
        printf("%d - %s\n", i, items[i]); 
    }
    // Get user input.
    while(!kbhit());
    int select;
    select = getch() - '0';
    return select; //return the selected value from char to int 
}

/*|cursorMenu|---------------------------------------------------------------//
#
# Description:
# This function... prints out a menu with a scrollable cursor
#
# Inputs:
# char* title - title of the menu as a string or char array
# const char* items - string values of each selection as an array pointer
# const int nItems - number of the menu items
#
# Returns: select - val of selected item
#
# Last Modified: Mar 05, 2025 by Peter Stogneff
# ---------------------------------------------------------------------------*/
int cursorMenu(char *title, const char*items[], const int nItems)
{
    char keyPress;
    int select = 0; //cursor position
    do
    {   
        //cursor wrap
        if (select < 0){
            select = nItems-1;
        }
        else if (select > nItems-1){
            select = 0;
        }
        //title and header
        printf("%s\n><*><*><*><*><*><*><*>*<*>< \n",title);
        for (int i = 0; i < nItems; i++)
        {
            //print menu item
            printf("%d - %s", i, items[i]);
            //if cursor position is on menu item print cursor
            if(i == select){
                printf(" <-");
            }
            printf("\n");
        }
        //get user input
        while(!kbhit());
        keyPress = getch();
        switch (keyPress)
        {
        case 'w':
            select--; //move cursor up
            break;
        case 's':
            select++; //move cursor down
            break;
        case 'd':
            return select; //return the value
        default: //any other keypresses do nothing
            break;
        }
        system("CLS");
    } while (keyPress != 'd');
}