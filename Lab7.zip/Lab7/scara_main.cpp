/*|SCARA Simulator|------------------------------------------------------------
#
# Project: ROBT 1270 - SCARA Simulator Basic Control
# Program: scara_main.c
#
# Description:
#   This program demonstrates basic control over the SCARA Robot Simulator. The
# simulator moves with only commands to control the motor angles. To move to a
# desired (x, y) coordinate requires the implementation of inverse kinematics.
# Other available commands are listed below.
#
# Other Programs:
#   ScaraRobotSimulator.exe (Version 4.3)
#
# Simulator Commands:
#  - PEN_UP
#  - PEN_DOWN
#  - PEN_COLOR <r> <g> <b>
#  - CYCLE_PEN_COLORS ON/OFF
#  - ROTATE_JOINT ANG1 <deg1> ANG2 <deg2>
#  - CLEAR_TRACE
#  - CLEAR_REMOTE_COMMAND_LOG
#  - CLEAR_POSITION_LOG
#  - SHUTDOWN_SIMULATION
#  - MOTOR_SPEED HIGH/MEDIUM/LOW
#  - MESSAGE <"string">
#  - HOME
#  - END
#
# Other Information:
#  - IP Address: 127.0.0.1 Port 1270
#  - BCIT Blue: 10 64 109
#  - If using VS Code, add the following args to tasks.json g++ build task.
#     "-std=c++11"
#		"-lwsock32"
#		"-Wno-deprecated"
#  - Also change the "${file}" argument to "*.cpp". This is a .cpp wildcard
#  - that will grab other .cpp files in the folder.
#
# Author: Peter Stogneff
# Date Created: 03/25/2025
# Last Modified: 04/01/2025
# -----------------------------------------------------------------------------*/
#pragma warning(disable:4996)  // get rid of some microsoft-specific warnings.
   
/*|Includes|-------------------------------------------------------------------*/
#include <stdio.h>  // <list of functions used>
#include <math.h>   // <list of functions used>
#include <stdlib.h> //abs() 
#include "robot.h"  // <list of functions used> // NOTE: DO NOT REMOVE.
#include "menu.h"
#include "penColor.h"

/*|CONSTANTS|------------------------------------------------------------------*/
#define L1                    350.0
#define L2                    250.0
#define MAX_ABS_THETA1_DEG    150.0
#define MAX_ABS_THETA2_DEG    170.0
#define MAX_STRING            256
#define PI                    3.14159265358979323846
#define LEFT_ARM_SOLUTION     0
#define RIGHT_ARM_SOLUTION    1

/*|Function Prototypes|--------------------------------------------------------*/
double DegToRad(double);  // returns angle in radians from input angle in degrees
double RadToDeg(double);  // returns angle in degrees from input angle in radians
int scaraFK(double, double, double*, double*);
int scaraIK(double, double, double*, double*, char);
void moveScaraFK(void);
void moveScaraIK(void);

/*|Globals|--------------------------------------------------------------------*/
CRobot robot;     // the global robot Class instance.  Can be used everywhere
                  // robot.Initialize()
                  // robot.Send()
                  // robot.Close()

/*|CONSTANTS|------------------------------------------------------------------*/
#define MAX_STRING            256

int main(){

    
   // Variables
   char commandString[MAX_STRING];   // string for simulator commands
   double thetaDeg1,thetaDeg2;
   int* penState = 0;

   //initiailize the strings for the menu
   char titleText[80] = "Lab 7: Moving Scara Sim Using Angles";
   const int optionNum[5] = {0,1,2,3,4};
   const char *options[5] = {
   "------- EXIT -------",
   "Forward Kinematics..",
   "Inverse Kinematics..",
   "Change Pen Color!...",
   "Clear Traces Y'know."};

   // Open a connection with the simulator
   if(!robot.Initialize()) return 0;
   
   // here are examples of how to send the robot commands. must use robot.
   robot.Send("CYCLE_PEN_COLORS OFF\n");  // DON'T FORGET \n AT THE END OF _EVERY_ COMMAND
   robot.Send("PEN_COLOR 0 0 255\n");

   //color and clear system
   system("COLOR 0A");
   system("CLS");

   //generate starting menu
   int select = 5;
   while(select!=0){
      select = generateMenu( titleText, options, sizeof(optionNum)/sizeof(optionNum[0]));
      switch (select){
         case 4:
            robot.Send("CLEAR_TRACE\n");
            robot.Send("CLEAR_REMOTE_COMMAND_LOG\n");
            robot.Send("CLEAR_POSITION_LOG\n");
            break;
         case 3:
            robot.Send("CYCLE_PEN_COLORS OFF\n");
            robot.Send(changePenColor(commandString));
            break;
         case 2:
            system("CLS");
            moveScaraIK();
            break;
         case 1:
            system("CLS");
            moveScaraFK();
            break;
         default:
            select = 0;
            break;
      }
   }

   /* And here is how you will move the robot more generally by calculating thetaDeg1 and thetaDeg2 variables. 
   // Note those are your variable names ...   scaraIK would be called first to calculate thetaDeg1 and thetaDeg2
   thetaDeg1=-45.0; // define some angles. Arbitrary.  
   thetaDeg2=-155.0;
   sprintf(commandString, "ROTATE_JOINT ANG1 %.2lf ANG2 %.2lf\n", thetaDeg1, thetaDeg2);
   robot.Send(commandString);*/

   robot.Send("HOME\n");

   getchar();

   robot.Send("CLEAR_REMOTE_COMMAND_LOG\n");
   robot.Send("CLEAR_POSITION_LOG\n");
   robot.Send("MESSAGE Bye-Bye\n");
   robot.Send("SHUTDOWN_SIMULATION\n");
   robot.Send("END\n");

   printf("\n\nPress ENTER to end the program...\n");
   getchar();

   
   robot.Close(); // close remote connection
   return 0;
}


//---------------------------------------------------------------------------------------
// Returns angle in radians from input angle in degrees.  Robot only accepts degrees!!
double DegToRad(double angDeg)
{
   return (angDeg*PI)/180;
}

//---------------------------------------------------------------------------------------
// Returns angle in radians from input angle in degrees
double RadToDeg(double angRad)
{
  return (angRad*180)/PI;
}

/****************************************************************************************
* Function: scaraFK
*
* Description:
* This function will calculate the x,y coordinates given two joint angles.
*
* Inputs:
* ang1 - Angle of joint 1 in degrees.
* ang2 - Angle of joint 2 in degrees.
* toolX - The tool position along the x-axis. Pointer
* toolY - The tool position along the y-axis. Pointer
*
* Returns:
* inRange - (0) in range, (-1) out of range
*
*****************************************************************************************/
int scaraFK(double ang1, double ang2, double* toolX, double* toolY) {
   double Rang1 = RadToDeg(ang1);
   double Rang2 = RadToDeg(ang2);
   int inRange = -1;
   *toolX = L1 * cos(Rang1) + L2 * cos(Rang1 + Rang2);
   *toolY = L1 * sin (Rang1) + L2 * cos(Rang1 + Rang2);
   if (((fabs(ang1)) <= MAX_ABS_THETA1_DEG) && ((fabs(ang2)) <= MAX_ABS_THETA2_DEG)){
      inRange = 0;
   }
   return inRange; 
}

/****************************************************************************************
* Function: scaraIK
*
* Description:
* This function will calculate two joint angles given the x,y coordinates.
*
* Inputs:
* toolX - The tool position along the x-axis.
* toolY - The tool position along the y-axis.
* ang1 - Angle of joint 1 in degrees. Pointer
* ang2 - Angle of joint 2 in degrees. Pointer
* arm - Selects which solution to try.
*
* Returns:
* inRange - (0) in range, (-1) out of range
*
*****************************************************************************************/
int scaraIK(double toolX, double toolY, double* ang1, double* ang2, char arm) {
   int inRange = -1;

   double L = sqrt((toolX*toolX) + (toolY*toolY));
   double beta = atan2(toolY,toolX);
   double alpha = acos(((L2*L2)-(L*L)-L1*L1)/(-2*L*L1));

   if(arm == 'L'){
      *ang1 = beta + alpha;
   }
   else if (arm == 'R'){
      *ang1 = beta - alpha;
   }
   else{
      *ang1 = 1000; //to make it out of range cuz arm solution isnt valid
   }

   *ang2 = atan2((toolY-(L1*sin(*ang1))),(toolX - (L1 * cos(*ang1))))-(*ang1);

   *ang1 = RadToDeg(*ang1);
   *ang2 = RadToDeg(*ang2);

   if(*ang2 < -180){
      *ang2+= 360;
   }
   else if (*ang2 > 180){
      *ang2-= 360;
   }
   //test command
   //printf("/%lf,%lf/\n", fabs(*ang1), fabs(*ang2));

   if (((fabs(*ang1)) <= MAX_ABS_THETA1_DEG) && (fabs((*ang2)) <= MAX_ABS_THETA2_DEG)){
      inRange = 0;
   }
   return inRange; 
}

/****************************************************************************************
* Function: moveScaraFK
*
* Description:
* This function will ask the user for SCARA joint variables in degrees. Then ask the
* user for the pen position and display the X,Y position.
*
* Inputs: void
*
* Returns: void
*
*****************************************************************************************/
void moveScaraFK(void) {
   double toolX, toolY;
   double theta1, theta2;
   char penPos;
   do{
      printf("input the two joint angles you would like to move the arm to (Θ1,Θ2) ");
      scanf("%lf, %lf", &theta1, &theta2);
      getchar();

      int inRange = scaraFK(theta1, theta2, &toolX, &toolY);
      char VAR[MAX_STRING];
      if (inRange == 0) {
         printf("would you like the pen up or down? (U/D) ");
         scanf(" %c",&penPos);
         getchar();
         if (penPos == 'U'){
            printf("moving to %.1lf, %.1lf with pen up\n", toolX, toolY);
            robot.Send("PEN_UP\n");
         }
         else if (penPos == 'D'){
            printf("moving to %.1lf, %.1lf with pen down\n", toolX, toolY);
            robot.Send("PEN_DOWN\n");
         }
         else{
            printf("That's not right...\n");
            inRange = -1;
         }
            sprintf(VAR, "ROTATE_JOINT ANG1 %lf ANG2 %lf\n", theta1, theta2);
            robot.Send(VAR);
      }
      else{ 
         printf("ERROR out of range!\n");
      }
   }while(theta1 != 0 || theta2 != 0);
}

/****************************************************************************************
* Function: moveScaraIK
*
* Description:
* This function will ask the user for SCARA joint variables in degrees. Then ask the
* user for the pen position and display the X,Y position.
*
* Inputs: void
*
* Returns: void
*
*****************************************************************************************/
void moveScaraIK(void) {
    double toolX, toolY;
    double theta1, theta2;
    char penPos, armSol;
    
    do{
      printf("input the two coordinates you would like to move the arm to (X,Y) ");
      scanf("%lf, %lf",&toolX, &toolY);
      getchar();

      printf("Would you like the left or right arm solution? (L/R) ");
      scanf(" %c", &armSol);
      getchar();

      int inRange = scaraIK(toolX, toolY, &theta1, &theta2, armSol);
      //test command
      //printf("<%d>\n",inRange);
      char VAR[MAX_STRING];

      if (inRange == 0) {
         printf("would you like the pen up or down? (U/D) ");
         scanf(" %c",&penPos);
         getchar();
         if (penPos == 'U'){
            printf("the angles %.1lf, %.1lf will move to %.1lf, %.1lf with pen up\n", theta1, theta2, toolX, toolY);
            robot.Send("PEN_UP\n");
         }
         else if (penPos == 'D'){
            printf("the angles %.1lf, %.1lf will move to %.1lf, %.1lf with pen down\n", theta1, theta2, toolX, toolY);
            robot.Send("PEN_DOWN\n");
         }
         else{
            printf("That's not right...\n");
            inRange = -1;
         }
            sprintf(VAR, "ROTATE_JOINT ANG1 %lf ANG2 %lf\n", theta1, theta2);
            robot.Send(VAR);
      }
      else{ 
         printf("ERROR out of range!\n");
      }
   }while(toolX != 0 || toolY != 0);
 }


/*
   // Initialize scaraState
//Initialize simulator from this point
scaraTool = { 'u', 0, 0, 255 };
scaraState = initScaraState(300, 300, RIGHT_ARM_SOLUTION, scaraTool, 'H');
moveScaraJ(&scaraState);
//Now copy the set of lines you can draw, start with the easiest set
// Easy set of lines
lineData = initLine(300, 0, 300, 300, 10);
moveScaraL(&scaraState, lineData);
lineData = initLine(100, 500, 300, 300, 20);
moveScaraL(&scaraState, lineData);
lineData = initLine(300, 0, 300, -300, 10);
moveScaraL(&scaraState, lineData);
lineData = initLine(100, -500, 300, -300, 20);
moveScaraL(&scaraState, lineData);
// Medium set of lines
lineData = initLine(0, 600, 600, 0, 20);
moveScaraL(&scaraState, lineData);
lineData = initLine(600, 0, 0, -600, 20);
moveScaraL(&scaraState, lineData);
lineData = initLine(300, 300, -500, 300, 10);
moveScaraL(&scaraState, lineData);
lineData = initLine(-500, 300, -300, 500, 5);
moveScaraL(&scaraState, lineData);
lineData = initLine(300, -300, -500, -300, 10);
moveScaraL(&scaraState, lineData);
lineData = initLine(-500, -300, -300, -500, 5);
moveScaraL(&scaraState, lineData);
// Hard set of lines
lineData = initLine(-500, 300, 600, 0, 20);
moveScaraL(&scaraState, lineData);
lineData = initLine(600, 0, -300, 500, 20);
moveScaraL(&scaraState, lineData);
lineData = initLine(-500, -300, 600, 0, 20);
moveScaraL(&scaraState, lineData);
lineData = initLine(600, 0, -300, -500, 20);
moveScaraL(&scaraState, lineData);
lineData = initLine(-500, -300, -300, 500, 10);
moveScaraL(&scaraState, lineData);
lineData = initLine(-500, 300, -300, -500, 10);
moveScaraL(&scaraState, lineData);
// Challenge set [Bonus]
lineData = initLine(-500, 300, 0, -600, 20);
moveScaraL(&scaraState, lineData);
lineData = initLine(0, -600, -300, 500, 20);
moveScaraL(&scaraState, lineData);
lineData = initLine(-500, -300, 0, 600, 20);
moveScaraL(&scaraState, lineData);
lineData = initLine(0, 600, -300, -500, 20);
moveScaraL(&scaraState, lineData);
*/