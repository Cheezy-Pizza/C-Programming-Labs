#ifndef CHANGEPENCOLOR_H
#define CHANGEPENCOLOR_H
/*|Defininitions and Includes|-----------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <conio.h> // kbhit, getch
#include <string.h>
#include "robot.h"  // <list of functions used> // NOTE: DO NOT REMOVE.

//|FUNCTION DECLARATIONS|//--------------------------------------------------//
// send in an array (preferably empty, it will be overwritten), and it will
// output an array in the form "PEN_COLOR %d %d %d\n"
char* changePenColor(char*);

#endif