/*|Pointers & Arrays|--------------------------------------------------------//

 Program: ROBT1270

 Description:
   A collection of two functions that:
   -Generates a selectable menu
   -Generates a scrollable menu

 Author: Peter Stogneff
 Date Created: 02/26/2025
 Last Modified: 03/19/2025
 ---------------------------------------------------------------------------*/
#ifndef MENU_H
#define MENU_H
/*|Defininitions and Includes|-----------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <conio.h> // kbhit, getch
#include <string.h>

//|FUNCTION DECLARATIONS|//--------------------------------------------------//
int cursorMenu(char *, const char*[], const int);
int generateMenu(char *, const char*[], const int);

#endif

// -------EXAMPLE OF HOW TO USE GENERATE MENU -------- //
    /*//initiailize the strings for the menu
    char titleText[80] = "Lab 6: Pointers and Arrays";
    const int optionNum[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
    const char *options[10] = {
    "------- EXIT -------",
    "Answers to ELEX 2220",
    "Answers to MATH 2342",
    "Answers to MECH 1210",
    "Really Bad Sort.....",
    "Sort Array Example..",
    "Classic Menu Style..",
    "Cursor Menu Style...",
    "Scrolling Menu Style",
    "Condensed Menu Style"};
    //color and clear system
    system("COLOR 0A");
    system("CLS");
    //generate starting menu
    int select = generateMenu( titleText, options, sizeof(optionNum)/sizeof(optionNum[0]));*/